# enif_iuc
For subscribing and publishing certain topics through Serial
----------
## Dependencies
Serial communication depends on the [serial library](https://github.com/wjwwood/serial).

```sh
cd ~/catkin_ws/src && git clone git://github.com/wjwwood/serial.git
cd serial && make
sudo make install
```