^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package hector_sensors_gazebo
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.5.1 (2018-06-29)
------------------

0.5.0 (2016-06-24)
------------------

0.4.1 (2016-06-24)
------------------

0.4.0 (2015-11-07)
------------------

0.3.8 (2016-06-24)
------------------

0.3.7 (2015-11-07)
------------------

0.3.6 (2015-03-21)
------------------

0.3.5 (2015-02-23)
------------------

0.3.4 (2014-09-01)
------------------

0.3.3 (2014-05-27)
------------------

0.3.2 (2014-03-30)
------------------
* removed metapackage tag from hector_sensors_gazebo to not break packages depending on it
* hector_gazebo: Made hector_gazebo and hector_sensors_gazebo true metapackages
* Moved package from hector_models to hector_gazebo
* Contributors: Johannes Meyer

0.3.0 (2013-09-02)
------------------
* catkinized stack hector_models
