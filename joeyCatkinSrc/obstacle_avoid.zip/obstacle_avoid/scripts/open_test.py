#!/usr/bin/env python
# creates vector in direction of desired travel.



import rospy
import math
#from geometry_msgs.msg import PoseStamped
#from geometry_msgs.msg import Twist
#from geometry_msgs.msg import Vector3Stamped
from sensor_msgs.msg import LaserScan
#from visualization_msgs.msg import Marker
import dji_sdk.msg
#from std_msgs.msg import Header
import genpy
import tf
from collections import namedtuple
pf = [0,0] #[angle,mag]
open_sector = []
avoid_vector = []
xy = namedtuple("xy","x y")
past_choices = []
past_choice = xy(0, 0)
past_choices += [past_choice]
gg = 0
heading = 0
pos_flag = 0
flag_first_heading = 0 ## for joystick target
new_global_x = []## for joystick target
MyStruct = namedtuple("Mystruct", "start stop narrow")
lat_lon = [0,0]
waypoint = [0,0]
joy_target = [0,0]

def callback3(msg):
    global heading
    heading = math.atan2(msg.vy, msg.vx )


def callback4(msg):
    global lat_lon, pos_flag
    lat_lon = [msg.latitude, msg.longitude]
    pos_flag = 1


def callback(msg):
    #position = msg.pose.position
    #quat = msg.pose.orientation
    global pos_flag, lat_lon
    quat = [msg.q0, msg.q1, msg.q2, msg.q3]
    if pos_flag == 1:
        pos_flag = 0
        command(lat_lon[0],lat_lon[1],0,quat)


def get_target_from_joy(msg):
    global joy_target
    joy_target[0] = msg.roll
    joy_target[1] = msg.pitch


#def callback5(msg):
#    global waypoint
#    waypoint = [msg.latitude, msg.longitude]


def callback2(header):

    ranges = list(header.ranges)
    angle_increment = header.angle_increment
    angle_min = header.angle_min
    ranges = fill_blind_spot(ranges, angle_min,header.angle_max, angle_increment)
    #pub_new_laser(ranges, header)
    global open_sector, avoid_vector
    [open_sector, avoid_vector] = open_sectors(ranges, angle_increment) #global
    if len(open_sector) == 0:
        print "POTENTIAL FIELD"
        potential_field(ranges, angle_increment)


def fill_blind_spot(ranges, angle_min, angle_max, angle_increment):
    length = len(ranges)
    jj = 0
    for M in ranges:  # replace inf and nan to 5
        #if M > 5:       #added for sim b/c diffrent sesnors that can see much farther
        #    ranges[jj] = 5
        if math.isnan(M) or math.isinf(M):
            ranges[jj] = 5
        jj += 1
    r2 = ranges[0]
    r1 = ranges[length - 1]
    angle = angle_min
    # get slope
    x1 = (math.cos(angle_max) * r1)
    y1 = (math.sin(angle_max) * r1)
    x2 = (math.cos(angle_min) * r2)
    y2 = (math.sin(angle_min) * r2)
    if (x2-x1 == 0):
        slope = 1000
    else :
        slope = (y2 - y1) / (x2 - x1)
    b = y2 - slope * x2
    while angle > -3.1415:
        gap_M = [b / (math.sin(angle) - slope * math.cos(angle))]
        ranges = gap_M + ranges
        angle -= angle_increment
    angle = angle_max
    while angle < 3.1415:
        gap_M = [b / (math.sin((angle)) - slope * math.cos(angle))]
        ranges = ranges + gap_M
        angle += angle_increment
    return ranges


def potential_field(ranges, angle_increment):
    global open_sector
    sum_inv_x = 0
    sum_inv_y = 0
    s = .05
    angle = 3.1415
    for M in ranges:
        x = (math.cos(angle)*M)
        y = (math.sin(angle)*M)
        sum_inv_x += -x*(s/(M*M))
        sum_inv_y += -y*(s/(M*M))
        angle += angle_increment

    rad_angle = math.atan2(sum_inv_y,sum_inv_x)
    mag = math.sqrt(sum_inv_x**2.0+sum_inv_y**2.0)

    global pf
    pf = [rad_angle, mag]   #gloabl variable used by command


def angle_between(start, stop):
    # abs value fo angle diff betwee two values 0 to 2pi start before stop ccw
    if start > 3.14 and stop > 3.14:
        diff = start - stop
    elif start < 3.14 and stop < 3.14:
        diff = start - stop
    else:
        if start > 3.14:
            start = start - 2*3.14
        diff = - start + stop
    return math.fabs(diff)


def open_sectors(ranges, angle_increment):

    angle = 3.1415  # TODO fix so open sect works for sectors starting at 3.14
    open_angles = []
    m = 0
    avoid_vector = [0, 0]
    max_dis = 2
    print 'OPEN SECTOR ---------------'
    while m < len(ranges) - 1:
        if ranges[m] >= max_dis:
            start = angle
            while (ranges[m] >= max_dis):
                m += 1  # increment through ranges
                angle += angle_increment
                if angle > 3.14 * 2:
                    angle = 0
                if m > len(ranges) - 1:
                    m -= 1
                    break
            stop = angle
            if stop >= 3.14:  # TODO: add in ability for completly open range.
                stop = 3.13
            angle_diff = angle_between(start, stop)
            if (angle_diff > .35):  # min gap
                if (angle_diff > .7):
                    narrow = 0
                else:
                    narrow = 1
                open_sect = MyStruct(start, stop, narrow)

                open_angles = open_angles + [open_sect]
        angle += angle_increment
        if angle > 3.14 * 2:
            angle = 0
        if ranges[m] < 1:
            avoid_vector[0] -= (1 - .7) * math.cos(angle)
            avoid_vector[1] -= (1 - .7) * math.sin(angle)

        m += 1  # increment through ranges
    if len(open_angles) > 0:
        open_angles = open_angles + [open_angles[0]]

    return [open_angles, avoid_vector]


def find_heading(start, stop, narrow, target, t_in_sector):
    add_to_start = 0.2
    add_to_stop = -0.2
    if (narrow == 1):
        x_y = [math.cos(start) + math.cos(stop), math.sin(start) + math.sin(stop)]
        print "narrow"
    elif t_in_sector == 1:
        print "t in sector"
        if angle_between(start, target) > .2 and angle_between(target, stop) > .2:
            x_y = [math.cos(target), math.sin(target)]
        else:  # two close to wall to head directly for target
            if angle_between(start, target) < angle_between(target, stop):
                x_y = [math.cos(start + add_to_start), math.sin(start + add_to_start)]
            else:

                x_y = [math.cos(stop + add_to_stop), math.sin(stop + add_to_stop)]
    else:

        if (start < 3.14 and stop < 3.14) or (start > 3.14 and stop > 3.14):  # sector does not cross x axis
            if math.fabs(start - target) < math.fabs(stop - target):  # of true closer to start
                x_y = [math.cos(start + add_to_start), math.sin(start + add_to_start)]
                print "closer to start 1"
            else:
                x_y = [math.cos(stop + add_to_stop), math.sin(stop + add_to_stop)]
                print "closer to stop 1"
        else:  # sector does cross x axis
            if target > 3.14:  # to find diff to stop angle depending on what side of the x axis th target vector is on
                angle_to_start = start - 2 * 3.14 - (target - 2 * 3.14)  # tartget on the same side as  start
            else:  # tartget on side as stop
                angle_to_start = math.fabs(stop - 2 * 3.14) + target
            if angle_to_start < math.fabs(stop - target):  # closer to start
                x_y = [math.cos(start + add_to_start), math.sin(start + add_to_start)]
                print "closer to start", start
            else:
                x_y = [math.cos(stop + add_to_stop), math.sin(stop + add_to_stop)]
                print "closer to stop", stop
    # cycle through and avoid close obstacles

    return x_y


def add_past_choice(target, past):
    length = len(past)
    x = 0
    y = 0
    for ii in range(0, length-1):
        x += past[ii].x
        y += past[ii].y
    if length > 0:
        x /= length
        y /= length
    return math.atan2(y + math.sin(target) , x + math.cos(target) )


def command(x,y,z,quaternion):
    global pf, heading
    global open_sector, avoid_vector
    global pot_flag
    global gg, past_choice, past_choices
    global waypoint
    global flag_first_heading, new_global_x, joy_target  # for controller target control
    msg = Twist() # for twist topic velocit commands
    # orientation of vessel
   # quaternion = [quat.x, quat.y, quat.z, quat.w]
    euler = tf.transformations.euler_from_quaternion(quaternion) #euler[2] is pitch

    # Const alt control
    #z_desired = 1  # desired hieght
    #alt_gain = 1
    #msg.linear.z = (z_desired - z)*alt_gain

    # get direction of motion
    #heading = math.atan2((y-old_y),(x-old_x))
    print "heading in ground frame", heading
    # set target location
    #t_x_location = 40.76542#waypoint[0]
    #t_y_location = -111.857#waypoint[1]
    t_x_joy = joy_target[0]
    t_y_joy = joy_target[1] # TODO set from joy command

    # average of first yaw reading for intial yaw is new glabl frame x axis
    if flag_first_heading == 0:
        new_global_x = [math.cos(euler[2]), math.sin(euler[2])]
        print 'new gobal;', new_global_x
        flag_first_heading += 1
    elif flag_first_heading < 50:
        new_global_x[0] += math.cos(euler[2])
        new_global_x[1] += math.sin(euler[2])
        flag_first_heading += 1
    frame_global_to_initial = math.atan2(new_global_x[1], new_global_x[0])

    #get angle to target
    #target_angle_global = math.atan2((t_y_location-y),(t_x_location-x))
    # get angle to target
    # use for gloab target: target_angle_global = math.atan2((t_y_location-y),(t_x_location-x))
    target_vector_global = [t_x_joy * math.cos(frame_global_to_initial) - t_y_joy * math.sin(frame_global_to_initial),
                            t_x_joy * math.sin(frame_global_to_initial) + t_y_joy * math.cos(frame_global_to_initial)]
    target_angle_global = math.atan2(target_vector_global[1], target_vector_global[0])
    print "target_angle_global", target_angle_global

    # set angular z so direction of motion(heading) amd pitch are the same
    #diff = euler[2] - heading
    #if (math.fabs(diff) > 3.14):
    #    msg.angular.z = 1 * diff
    #if (math.fabs(diff) < 3.14):
    #    msg.angular.z = -1 * diff
    print "yaw angle ", eu1er[2]

    if len(open_sector) != 0:#pot_flag == 0: #open sector

        target_angle_quad_f = (target_angle_global - euler[2])
        print "target angel quad f", target_angle_quad_f
        target_angle_quad_f = add_past_choice(target_angle_quad_f, past_choices)
        print "target angle apst", target_angle_quad_f
        target_angle_quad_f = math.fabs(target_angle_quad_f) % 6.14 * math.fabs(target_angle_quad_f) / target_angle_quad_f # set angel between 0 and 2pi


        if target_angle_quad_f < 0:
            target_angle_quad_f += 3.14 * 2
        x_y = [0, 0]
        ii=0 #initialize iteration for while loop
        print "target_angle", target_angle_quad_f
        while ii <= len(open_sector) - 2:
            print "start of sector", open_sector[ii].start
            print "end of sector", open_sector[ii].stop
            if open_sector[ii].stop > open_sector[ii].start:  # sector does not cross x axis
                if (open_sector[ii].start < target_angle_quad_f and open_sector[
                    ii].stop > target_angle_quad_f):  # target in sector
                    x_y = find_heading(open_sector[ii].start, open_sector[ii].stop, open_sector[ii].narrow,
                                       target_angle_quad_f, 1)
                    print "1"
                    break
            elif open_sector[ii].stop < open_sector[ii].start:  # sector crosses x axis
                if (open_sector[ii].start < target_angle_quad_f or open_sector[
                    ii].stop > target_angle_quad_f):  # targer in sector
                    x_y = find_heading(open_sector[ii].start, open_sector[ii].stop, open_sector[ii].narrow,
                                       target_angle_quad_f, 1)
                    print "2"
                    break
            if open_sector[ii].stop < open_sector[ii + 1].start:  # if closed sector does not cross x axis
                if open_sector[ii].stop < target_angle_quad_f and open_sector[
                            ii + 1].start > target_angle_quad_f:  # in between open sectors
                    if math.fabs(open_sector[ii].stop - target_angle_quad_f) < math.fabs(
                                    open_sector[ii + 1].start - target_angle_quad_f):
                        x_y = find_heading(open_sector[ii].start, open_sector[ii].stop, open_sector[ii].narrow,
                                           target_angle_quad_f, 0)
                        print "3"
                        break
                    else:
                        x_y = find_heading(open_sector[ii + 1].start, open_sector[ii + 1].stop,
                                           open_sector[ii + 1].narrow, target_angle_quad_f, 0)
                        print "4"
                        break

            elif open_sector[ii].stop > open_sector[ii + 1].start:  # angles between sectors cross x axis
                if open_sector[ii].stop < target_angle_quad_f or open_sector[
                            ii + 1].start > target_angle_quad_f:  # target is in closed sector that crosses x axis
                    if target_angle_quad_f > 3.14:  # to find diff to stop angle depending on what side of the x axis th target vector is on
                        angle_to_stop = open_sector[ii].stop - 2 * 3.14 - (
                        target_angle_quad_f - 2 * 3.14)  # tartget on the same side as  stop.ii
                    else:  # on 0 to pi side
                        angle_to_stop = math.fabs(open_sector[ii].stop - 2 * 3.14) + target_angle_quad_f
                    if angle_to_stop > open_sector[ii + 1].start - target_angle_quad_f:  # if closser to sector ii+1

                        x_y = find_heading(open_sector[ii + 1].start, open_sector[ii + 1].stop,
                                           open_sector[ii + 1].narrow, target_angle_quad_f, 0)
                        print "5"
                        break
                    else:
                        x_y = find_heading(open_sector[ii].start, open_sector[ii].stop, open_sector[ii].narrow,
                                           target_angle_quad_f, 0)
                        print "6"
                        break
            ii += 1
        unit_x_y = [x_y[0] / math.sqrt(pow(x_y[0], 2) + pow(x_y[1], 2)),x_y[1] / math.sqrt(pow(x_y[0], 2) + pow(x_y[1], 2))]  # change x y vel command to unit vector
        # save comd
        if gg > 100 - 1:
            gg = 0
        choice = xy(unit_x_y[0], unit_x_y[1])
        if len(past_choices) <= 100:
            past_choices += [choice]
        else:
            past_choices[gg] = choice
            gg += 1

        if math.fabs(avoid_vector[0]) > 0 and math.fabs(avoid_vector[1]) > 0: # somthing is close enough to avoid
            unit_avoid = [avoid_vector[0] / math.sqrt(pow(avoid_vector[0], 2) + pow(avoid_vector[1], 2)), avoid_vector[1] / math.sqrt(pow(avoid_vector[0], 2) + pow(avoid_vector[1], 2))] # change void vector to unit vecotor
            print 'avoid vector x y', unit_avoid[0],'    ' ,unit_avoid[1]
            open_and_avoid = [unit_avoid[0] + unit_x_y[0], unit_avoid[1] + unit_x_y[1]] # add the void vector and open sector vector
            x_cmd = open_and_avoid[0] / math.sqrt(pow(open_and_avoid[0], 2) + pow(open_and_avoid[1], 2))
            y_cmd = open_and_avoid[1] / math.sqrt(pow(open_and_avoid[0], 2) + pow(open_and_avoid[1], 2))
            print "open and avoid", open_and_avoid
        else:
            x_cmd = unit_x_y[0] / math.sqrt(pow(unit_x_y[0], 2) + pow(unit_x_y[1], 2))
            y_cmd = unit_x_y[1] / math.sqrt(pow(unit_x_y[0], 2) + pow(unit_x_y[1], 2))
        print "x command ", x_cmd
        print "y command", y_cmd
        print "command angle ", math.atan2(y_cmd, x_cmd)
        print "\n\n"

    else: #use pf
        ##########################
        # set a some what arbitary magnitude and get components
        t_m = 4
        t_x = t_m * math.cos(target_angle_global)
        t_y = t_m * math.sin(target_angle_global)

        # get componets of pf vector
        pf_x = pf[1] * math.cos(pf[0] + euler[2])
        pf_y = pf[1] * math.sin(pf[0] + euler[2])

        # add pf and target to get new_target vector
        new_t_x = pf_x + t_x
        new_t_y = pf_y + t_y
        new_t_m = math.sqrt(math.pow(new_t_x, 2) + math.pow(new_t_y, 2))
        new_t_angle = math.atan2(new_t_y, new_t_x)

        # get new_taget unit vector in local quad frame
        new_t_x_quad_f = (new_t_x * math.cos(-euler[2]) - new_t_y * math.sin(-euler[2])) / new_t_m
        new_t_y_quad_f = (new_t_x * math.sin(-euler[2]) + new_t_y * math.cos(-euler[2])) / new_t_m

        x_cmd=new_t_x_quad_f
        y_cmd=new_t_y_quad_f
        # Save cmd
        if gg > 100 - 1:
            gg = 0
        choice = xy(x_cmd, y_cmd)
        if len(past_choices) <= 100:
            past_choices += [choice]
        else:
            past_choices[gg] = choice
            gg += 1
    msg.angular.x=0
    msg.angular.y=0

    msg.linear.x = x_cmd
    msg.linear.y = y_cmd
    pub = rospy.Publisher('cmd_vel', Twist, queue_size=10)
    pub.publish(msg)



def listener():
    rospy.init_node('listener', anonymous=True)
    rospy.Subscriber("dji_sdk/attitude_quaternion", dji_sdk.msg.AttitudeQuaternion, callback)
    rospy.Subscriber("dji_sdk/GlobalPosition", dji_sdk.msg.GlobalPosition, callback4)
    rospy.Subscriber("/scan", LaserScan, callback2)
    rospy.Subscriber("dji_sdk/Velocity", dji_sdk.msg.Velocity, callback3)
    rospy.Subscriber("dji_sdk/RCChannels", dji_sdk.msg.RCChannels, get_target_from_joy)
    #rospy.Subscriber("dji_sdk/Waypoint", dji_sdk.msg.Waypoint, callback5)
    rospy.spin()


if __name__ == '__main__':
    listener()
